package a.com.practicepageviewer;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ViewPager viewPager;
    private PagerAdapter pagerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<DataObject> getData = dataSource();
        viewPager = (ViewPager)findViewById(R.id.viewpager);
        CustomPageAdapter mCustomPagerAdapter = new CustomPageAdapter(MainActivity.this, getData);
        viewPager.setAdapter(mCustomPagerAdapter);
    }
    private List<DataObject> dataSource(){
        List<DataObject> data = new ArrayList<DataObject>();
        data.add(new DataObject(R.drawable.cutups, "Cutups"));
        data.add(new DataObject(R.drawable.disneyhot, "DisneyH"));
        data.add(new DataObject(R.drawable.disneynug, "DisneyN"));
        data.add(new DataObject(R.drawable.fried, "Fried"));
        data.add(new DataObject(R.drawable.liempo, "LCut"));
        data.add(new DataObject(R.drawable.marin, "Marin"));
        data.add(new DataObject(R.drawable.pepper, "Pepper"));
        data.add(new DataObject(R.drawable.spicy, "Spicy"));
        data.add(new DataObject(R.drawable.sweet, "Sweet"));
        data.add(new DataObject(R.drawable.whole, "Whole"));
        return data;
    }
}


